Static assets directory.

Add favicon.ico, og-image.jpg, and any other static files here.
They'll be served at the root of the deployed site.
