# Maison Hue — Matching Experience Prototype

A working React prototype of Maison Hue's AI shade-matching tool. To be integrated at `maisonhue.co.uk/match`.

## What this is

A self-contained React app that lets users:

1. Upload or take a photo of their roots
2. Tap multiple points to sample their colour (multi-point averaging)
3. Get a matched shade from our 28-pigment library (using LAB colour space + Delta-E matching)
4. Preview the match with a "Try It On" press-and-hold feature
5. At the end of the flow, enter their email to save their formula and join the founder waitlist

## Quick start (local development)

```bash
npm install
npm run dev
```

Then open http://localhost:5173

To build for production:

```bash
npm run build
```

Output goes to `dist/`.

## Integration notes for Emergent

### 1. Route

This should live at `maisonhue.co.uk/match` (private route — not linked from the holding page navigation yet).

The "COMING SOON" button on the holding page Matching Experience section should eventually be wired to either:
- Link directly to `/match`, OR
- Stay as soft email capture and we'll release the `/match` URL by invitation to the waitlist

(Decision pending — for now, build as a standalone page.)

### 2. ⚠️ IMPORTANT: window.storage needs replacing

The prototype uses `window.storage` to read/write a waitlist counter. **This API does not exist in a real browser** — it's specific to the environment the prototype was built in.

Search `MaisonHueMatch.jsx` for `window.storage` — there are ~3 usages. Please replace with:

**Option A (recommended):** wire to your real `/api/waitlist` endpoint
- On mount: GET current waitlist count → display in UI
- On email submit: POST `{ email, name, shade_id, shade_name, rgb_value, timestamp }` → return updated count

**Option B (interim):** stub with `localStorage` or just hardcode to a fixed number while you wire up the backend.

The user-facing copy refers to "the founder list" and "save your formula" — so the data we want to capture per submission:

- `email` (required)
- `name` (optional, for personalisation)
- `matched_shade_id` (e.g. `p7`)
- `matched_shade_name` (e.g. `Honey Bronze`)
- `matched_shade_hex` (e.g. `#9c7e4a`)
- `timestamp`
- `referrer` (optional, for tracking traffic source)

### 3. Email capture: "save your formula" model

Per our decision (option 1c from earlier), the user can:
- Use the matching tool freely without an email
- Get their match shown to them
- At the end, see a "Save your formula" prompt where email capture happens
- Email = soft conversion (waitlist + founder list)

The prototype already implements this flow. Just wire the POST.

### 4. Fonts

The prototype expects `Cormorant Garamond` (display) and `Inter` (body). Already loaded via Google Fonts in `index.html`.

### 5. Mobile-first

This is built mobile-first. Test on actual phones (iOS Safari + Android Chrome). The press-and-hold "Try It On" gesture and the touch-based sampling are mobile-critical.

### 6. Photo handling — GDPR note

Photos are processed entirely client-side. The image data never leaves the user's browser. The prototype does NOT upload photos anywhere — only the matched shade result + email are sent to the backend.

This must be made clear in:
- The privacy policy (Alisa is generating one via termly.io)
- A short notice on the photo upload screen (already present in the prototype)

### 7. What NOT to change

The prototype is the product. Please don't:
- Rewrite the colour-matching algorithm (it's tuned — RGB→LAB→Delta-E, with skin/lip rejection)
- Change the 28-pigment library
- Modify the visual design (museum-grade minimalist palette, restrained gold, near-black ink)
- Replace the Cormorant Garamond display font

Things that ARE fair game:
- Replacing `window.storage` (required, see above)
- Adding analytics (PostHog / GA4 / Plausible)
- Wiring real email capture endpoint
- Adding error states / loading states for the API calls
- Adding share-to-social buttons after match reveal (if you think it'll help virality)

## Project structure

```
maison-hue-prototype/
├── index.html              # HTML entry, Google Fonts, base styles
├── package.json            # Dependencies (React, Vite, lucide-react)
├── vite.config.js          # Vite build config
├── public/                 # Static assets (empty for now)
└── src/
    ├── main.jsx            # React entry point
    └── MaisonHueMatch.jsx  # The entire app — ~2000 lines, single file
```

The whole app is intentionally in one file for portability. Once integrated, feel free to break it into components if it helps your workflow.

## Dependencies

- `react` / `react-dom` (^18.3.1)
- `lucide-react` (^0.383.0) — icon library
- `vite` (^5.3.0) — build tool

No CSS framework. All styling is inline via the `c` object in `MaisonHueMatch.jsx`.

## Questions

Direct to Alisa (founder) or Claude (project assistant via Claude.ai).

---

Maison Hue · Hand-blended in the Cotswolds · London
